#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){

    ofSetEscapeQuitsApp(true);
    ofSetBackgroundAuto(false);
    ofBackground(55);


    gui = new ofxUICanvas();        //Creates a canvas at (0,0) using the default width

  	gui->addLabel("CV EFFECTS", OFX_UI_FONT_LARGE);

  	gui->addSpacer();
    gui->addLabelButton("load video", false);
    gui->addLabelButton("save video", false);
    gui->addLabelButton("export frames", false);
    gui->addLabelButton("save one frame", false);
  	gui->addSpacer();
  	gui->addLabel("background", OFX_UI_FONT_SMALL);
  	vector<string> backgroundOptions;
    backgroundOptions.push_back("black");
    backgroundOptions.push_back("video");
    backgroundOptions.push_back("frame");
	ofxUIRadio *backgroundRadio = (ofxUIRadio *) gui->addRadio("background", backgroundOptions, OFX_UI_ORIENTATION_HORIZONTAL);
    backgroundRadio->activateToggle("black");
    gui->addMinimalSlider("blend",0.0,255.0,0.0);

  	gui->addLabel("scale", OFX_UI_FONT_SMALL);
    vector<string> scales;
	scales.push_back("1/4");
	scales.push_back("1/3");
	scales.push_back("1/2");
	scales.push_back("2/3");
	scales.push_back("3/4");
	scales.push_back("1");

	scaleRadio = (ofxUIRadio *) gui->addRadio("scale", scales, OFX_UI_ORIENTATION_HORIZONTAL);

  	gui->addSpacer();

    vector<string> effects;
    effects.push_back("feature lines");
    effects.push_back("optical flow lines");
    effects.push_back("bg extract");
    ddl = gui->addDropDownList("effects", effects);
    ddl->setAllowMultiple(false);
    ddl->setAutoClose(true);
    ddl->setShowCurrentSelected(true);

    ofAddListener(gui->newGUIEvent, this, &ofApp::guiEvent);
    gui->loadSettings("settings.xml");

    gui->autoSizeToFitWidgets();


    scaleRadio->activateToggle("1");
    scaleFloat = 1.0;

    ofFile lastVideoName;

	if (lastVideoName.doesFileExist(ofToDataPath("lastVideoName.txt"))) {
        lastVideoName.open(ofToDataPath("lastVideoName.txt"));
        lastVideoName >> fileName;
        lastVideoName.close();
        openMovie (fileName);
	}


}

//--------------------------------------------------------------
void ofApp::update(){

    if (mMovie.isLoaded())
        mMovie.update();


}

//--------------------------------------------------------------
void ofApp::draw(){


    if (!mMovie.isLoaded()) {
            return;
        }


    if (!mMovie.isFrameNew()) {
    } else {

        cv::Mat frame(movieHeight,movieWidth,CV_8UC3,mMovie.getPixels());
        resized = myResize (frame, scaleFloat);


        if (blendLevel > 0) {
            ofEnableBlendMode(OF_BLENDMODE_ALPHA);
            ofSetColor(255,255,255,blendLevel);
        }

        if (backgroundMode==0) {
            ofSetColor (0,0,0,blendLevel);
            ofRect (moviePosX,moviePosY,movieWidth,movieHeight);
            ofSetColor(255,255,255,blendLevel);
        } else if (backgroundMode==1) {
            ofIm.setFromPixels(resized.data,(int)scaledWidth,(int)scaledHeight, OF_IMAGE_COLOR);
            ofIm.draw(moviePosX, moviePosY);
        } else if (backgroundMode==2) {
            firstFrame.draw(moviePosX,moviePosY);
        } else if (backgroundMode=-1) {
        }

        switch (effectNum) {

            case 0:
            //no effect
                ofIm.setFromPixels(resized.data,(int)scaledWidth,(int)scaledHeight, OF_IMAGE_COLOR);
                ofIm.draw(moviePosX, moviePosY);

            break;

            case 1:

                ofIm = ofImage(effectBgExtract(resized));
                ofIm.draw(moviePosX, moviePosY);

            break;

            case 2:

                effectGoodOpticalFlow(resized);

            break;

            case 3:

                ofIm.draw(moviePosX, moviePosY);
                effectFeatureLines(resized);

            break;


        }

    }

}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){

}


void ofApp::exit()
{
    gui->saveSettings("settings.xml");
    delete gui;

    // create or open a file
    ofFile pFile (ofToDataPath("lastVideoName.txt"),ofFile::WriteOnly);

    // add some lines of text
    pFile << fileName;

    // save file
    pFile.close();

}

void ofApp::guiEvent(ofxUIEventArgs &e)
{

    if(e.getName() == "load video")
    {

            ofxUIButton *labelbutton = e.getButton();

            if (labelbutton->getValue()) {

            ofFileDialogResult openFileResult = ofSystemLoadDialog("select a movie");

            //Check if the user opened a file
            if (openFileResult.bSuccess) {
                //We have a file, check it and process it
                openMovie(openFileResult.getPath());
                fileName = openFileResult.getPath();
            }
        }

    } else if(e.getName() == "scale")
    {
        ofxUIRadio *radio = (ofxUIRadio *) e.widget;
        int scaleChoice = radio->getValue();

        setScale(scaleChoice);

        setupEffect();

        ofClear(55);

    } else if(e.getName() == "save video")    {

        ofxUIButton *labelbutton = e.getButton();

        if (labelbutton->getValue())
            exportMovie();

    } else if(e.getName() == "export frames")    {

        ofxUIButton *labelbutton = e.getButton();

        if (labelbutton->getValue())
            exportFrames();

    } else if(e.getName() == "effects")    {

        ofxUIDropDownList *ddlist = (ofxUIDropDownList *) e.widget;
        vector<ofxUIWidget *> &selected = ddlist->getSelected();


         for(vector<ofxUIWidget *>::iterator it = selected.begin(); it != selected.end(); ++it)
            {
                ofxUILabelToggle *lt = (ofxUILabelToggle *) (*it);
                selectEffect(lt->getName());

            }

    } else if(e.getName() == "features")    {

        ofxUIMinimalSlider *minSli = (ofxUIMinimalSlider *) e.widget;
        MAX_FEATURES = (int)minSli->getValue();
        ofClear(55);
        setupEffect();

    } else if(e.getName() == "background")    {

        ofxUIRadio *radio = (ofxUIRadio *) e.widget;
        backgroundMode = radio->getValue();

    } else if(e.getName() == "blend")    {

        ofxUIMinimalSlider *sli = (ofxUIMinimalSlider *) e.widget;
        blendLevel = (int)sli->getValue();


    }
}

void ofApp::setScale(int scaleChoice) {
        switch (scaleChoice) {

        case 0:
            scaleFloat = 0.25;
            break;

        case 1:
            scaleFloat = 0.33333333333333333333;
            break;
        case 2:
            scaleFloat = 0.5;
            break;

        case 3:
            scaleFloat = 0.66666666666666666666;
            break;

        case 4:
            scaleFloat = 0.75;
            break;

        case 5:
            scaleFloat = 1.0;


        }

        scaledHeight = movieHeight * scaleFloat;
        scaledWidth = movieWidth * scaleFloat;
        setupEffect();

}

void ofApp::openMovie (string result) {

    if (mMovie.loadMovie(result)) {
        movieWidth = mMovie.getWidth();
        movieHeight = mMovie.getHeight();
        scaledWidth = (int)movieWidth * scaleFloat;
        scaledHeight = (int)movieHeight * scaleFloat;


        mMovie.play();

        //mMovie.pause();
	} else {
        ofSystemAlertDialog("the movie couldn't be loaded");
	}

}

void ofApp::exportMovie() {

        float rate;

        if (!mMovie.isLoaded()) {
            ofSystemAlertDialog("please load a movie first");
            return;
        }

        mMovie.setPaused(true);
        mMovie.firstFrame();

        if ((mMovie.getTotalNumFrames()!=0)&&(mMovie.getDuration()!=0)) {
            rate =  mMovie.getTotalNumFrames() / mMovie.getDuration() ;

        } else {

            rate =  24 ;

        }


        cout << "rate " << rate;


        //string saveFileName = "/dados/videos/multidao/testMovie";
        string saveFileName = "exported-";
        string fileExt = ".mov"; // ffmpeg uses the extension to determine the container type. run 'ffmpeg -formats' to see supported formats

        // override the default codecs if you like
        // run 'ffmpeg -codecs' to find out what your implementation supports (or -formats on some older versions)
        //vidRecorder.setVideoCodec("copy");
        //vidRecorder.setVideoCodec("copy");
        //vidRecorder.setVideoCodec("msmpeg4v2");
        vidRecorder.setVideoCodec("libx264");
        //vidRecorder.setPixelFormat("rgb24");
        //vidRecorder.setVideoCodec("mjpeg");
        vidRecorder.setVideoBitrate("50000k");
        vidRecorder.setAudioCodec("libmp3lame");

        vidRecorder.setAudioBitrate("192k");

        vidRecorder.setup(saveFileName+ofGetTimestampString()+fileExt, scaledWidth, scaledHeight, rate,44100,0);

        mMovie.nextFrame();
        mMovie.update();
        while (mMovie.getCurrentFrame()< mMovie.getTotalNumFrames()) {
            if (mMovie.isFrameNew()) {

                ofImage ofImTmp;

                cv::Mat frame(movieHeight,movieWidth,CV_8UC3,mMovie.getPixels());
                cv::Mat resized;
                resized = myResize (frame, scaleFloat);

                ofImTmp.setFromPixels(resized.data,resized.cols,resized.rows, OF_IMAGE_COLOR);
                vidRecorder.addFrame(ofImTmp.getPixelsRef());

                mMovie.nextFrame();
                mMovie.update();
                cout << mMovie.getCurrentFrame() << " "<< mMovie.getTotalNumFrames() << "\n";
            } else {
                mMovie.update();
                //ofSleepMillis(1);
            }
        }


        vidRecorder.close();
        ofSystemAlertDialog("done");

}

void ofApp::exportFrames() {

        string savePath = "exported_frames_"+ofGetTimestampString()+"/";

        ofDirectory dir;

        dir.createDirectory (savePath, false);

        int frameNumber = 0;

        //keyPressed(effect);//resets the effect

        mMovie.setPaused(true);
        mMovie.nextFrame();
        mMovie.update();
        while (mMovie.getCurrentFrame()< mMovie.getTotalNumFrames()) {
            if (mMovie.isFrameNew()) {

                cv::Mat frame(movieWidth,movieHeight,CV_8UC3,mMovie.getPixels());
                cv::Mat resized;
                resized = myResize (frame, scaleFloat);

                //draw();

                string frameString;
                ostringstream convert;

                convert << setfill('0') << setw (4) << frameNumber << ".jpg";
                frameString = convert.str();

                ofImage screen;
                screen.grabScreen(moviePosX,moviePosY,scaledWidth,scaledHeight);
                screen.saveImage(savePath+frameString);

                mMovie.nextFrame();
                mMovie.update();
                cout << mMovie.getCurrentFrame() << "\n";
                //frameNumber = mMovie.getCurrentFrame();
                frameNumber++;
            } else {
                mMovie.update();
                //ofSleepMillis(1);
            }

        }



}



cv::Mat ofApp::myResize (cv::Mat src, float s) {

            cv::Mat dst;

            if (s!=1.0) {
                    cv::resize (src, dst, cv::Size(), s, s );
                    return dst;

                } else {

                    return src.clone();

                }



}



/* effects */
void ofApp::selectEffect (string effectName) {
    if (effectName == "bg extract" ) {

        effectNum = 1;
        setupEffect();

    } else if (effectName == "optical flow lines") {


        effectNum = 2;
        setupEffect();

    } else if (effectName == "feature lines") {


        effectNum = 3;
        setupEffect();

    }

}


void ofApp::setupEffect() {

    firstFrame.setFromPixels(resized.data,(int)scaledWidth,(int)scaledHeight, OF_IMAGE_COLOR);

    switch (effectNum) {

        case 0:
        //no effect

            break;


        case 1:
        // bg extractor
            bgSubtractor = cv::BackgroundSubtractorMOG2 (60, 56.0, true);
            for (int i=0;i<toBeRemoved.size();i++)
                gui->removeWidget(toBeRemoved[i]);
            gui->autoSizeToFitWidgets();

            break;

        case 2:
        //optical flow

            if (!findInVector(toBeRemoved, "features")) {
                ofxUIMinimalSlider * featuresSlider = gui->addMinimalSlider("features", 0,500, 400);
                toBeRemoved.push_back("features");
                featuresSlider->setShowValue(false);


                gui->autoSizeToFitWidgets();
            }
            bgSubtractor = cv::BackgroundSubtractorMOG2 (60, 26.0, true);
            lastPointsOpticalFlow = std::vector<cv::Point2f>(MAX_FEATURES);
            goodFeatureDetector = cv::GoodFeaturesToTrackDetector (MAX_FEATURES);

            break;

        case 3:

            bgSubtractor = cv::BackgroundSubtractorMOG2 (60, 26.0, true);
            goodFeatureDetector = cv::GoodFeaturesToTrackDetector (MAX_FEATURES);

            break;
    }

}


ofImage ofApp::effectBgExtract (cv::Mat color_img) {

    ofImage ofImTmp;

    int th = color_img.rows;
    int tw = color_img.cols;

    cv::Mat imgReturn, bgMask;
    cv::Mat grey_img, blurred;

    cv::cvtColor(color_img, grey_img, CV_RGB2GRAY);

    bgSubtractor(grey_img,bgMask);

    blurred = bgMask.clone();
    for ( int i = 1; i < 5; i = i + 2 )
         cv::GaussianBlur( bgMask, blurred, cv::Size( i, i ), 0,0);

    cv::cvtColor(blurred, imgReturn, CV_GRAY2RGB);
    ofImTmp.setFromPixels(imgReturn.data,imgReturn.cols,imgReturn.rows, OF_IMAGE_COLOR);
    return ofImTmp;

}

void ofApp::effectGoodOpticalFlow (cv::Mat color_img) {


    vector<uchar> status;
    vector<float> errors;

    cv::Mat grey_img, bgMask;

    // beautiful glitch when initiliaze this way cv::Mat blank(h,w,CV_8UC3);
    //cv::Mat blank(color_img.rows,color_img.cols,CV_8UC3, cv::Scalar(50,50,50));

    cv::cvtColor(color_img, grey_img, CV_RGB2GRAY);
    bgSubtractor(grey_img,bgMask);

    if (firstFrameOpticalFlow) {
        lastImgOpticalFlow = bgMask.clone();
        firstFrameOpticalFlow = false;
    } else {
        //lastpoints = points;
        goodFeatureDetector.detect( lastImgOpticalFlow, keyPointsOpticalFlow );
        //points.resize(keypoints.size());
        for (unsigned int i=0;i<keyPointsOpticalFlow.size();i++) {
            lastPointsOpticalFlow[i].x = keyPointsOpticalFlow[i].pt.x;
            lastPointsOpticalFlow[i].y = keyPointsOpticalFlow[i].pt.y;
        }
        std::vector<cv::Point2f> points(MAX_FEATURES); // 500 corners as max

        //cv::TermCriteria tc (cv::TermCriteria::COUNT+cv::TermCriteria::EPS, 30, 0.01);

        cv::calcOpticalFlowPyrLK(lastImgOpticalFlow,bgMask,lastPointsOpticalFlow,points,status, errors, cv::Size(11,11));

        lastImgOpticalFlow= bgMask.clone();

        for (unsigned int i=0; i<points.size(); i++ ) {
            if( status[i]==0|| errors[i]>550 ) {
                continue;
            }

            //cv::Point p = lastpoints[i];
            //cv::Point q = points[i];
            //line(blank, p, q, cv::Scalar(230,230,230),1,CV_AA);
            //circle (color_img, p, 3, cv::Scalar(255),1,CV_AA);

            ofPushMatrix();
            ofTranslate(moviePosX,moviePosY);
            ofVec2f startPoint (lastPointsOpticalFlow[i].x, lastPointsOpticalFlow[i].y);
            ofVec2f endPoint ( points[i].x, points[i].y);

            if (startPoint.distance(endPoint) <  color_img.cols /50.0)
                ofLine (lastPointsOpticalFlow[i].x, lastPointsOpticalFlow[i].y, points[i].x, points[i].y);
            ofPopMatrix();

        }



    }


}

void ofApp::effectFeatureLines(cv::Mat color_img ) {

    vector<uchar> status;
    vector<float> errors;

    cv::Mat grey_img, bgMask;

    // beautiful glitch when initiliaze this way cv::Mat blank(h,w,CV_8UC3);
    //cv::Mat blank(color_img.rows,color_img.cols,CV_8UC3, cv::Scalar(50,50,50));

    cv::cvtColor(color_img, grey_img, CV_RGB2GRAY);
    bgSubtractor(grey_img,bgMask);

    goodFeatureDetector.detect( bgMask, keyPointsOpticalFlow );

    ofPushMatrix();
    ofTranslate(moviePosX,moviePosY);
    for (unsigned int i=0;i<keyPointsOpticalFlow.size();i+=2) {

            //ofVec2f startPoint (lastPointsOpticalFlow[i].x, lastPointsOpticalFlow[i].y);
            //ofVec2f endPoint ( points[i].x, points[i].y);

            //if (startPoint.distance(endPoint) <  color_img.cols /50.0)
        ofLine (keyPointsOpticalFlow[i].pt.x, keyPointsOpticalFlow[i].pt.y, keyPointsOpticalFlow[i+1].pt.x, keyPointsOpticalFlow[i+1].pt.y );
    }

    ofPopMatrix();



}

bool ofApp::findInVector (vector<string> haystack, string needle) {

    for (int i=0; i<haystack.size(); i++) {
        if (haystack[i]==needle)
            return true;

    }

    return false;

}

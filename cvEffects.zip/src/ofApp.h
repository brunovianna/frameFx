#pragma once

#include "ofMain.h"
#include "ofxUI.h"
#include "ofxOpenCv.h"
#include "ofxVideoRecorder.h"

#include "opencv2/video/background_segm.hpp"

class ofApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();

		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);


        ofxUICanvas *gui;
        ofxUIDropDownList *ddl;
        ofxUIRadio *scaleRadio;

        void setScale (int scaleChoice);
        vector<string> toBeRemoved;

        void exit();
        void guiEvent(ofxUIEventArgs &e);

        float movieWidth, movieHeight, scaledWidth, scaledHeight;
        float scaleFloat;

        string fileName;
        ofVideoPlayer 		mMovie;
        void openMovie(string _fileName);
        ofxVideoRecorder    vidRecorder;
        void exportMovie();
        void exportFrames();

        cv::Mat myResize(cv::Mat src, float s);
        cv::Mat resized;

        ofImage ofIm;

        float moviePosY = 10.0;
        float moviePosX = 240.0;

        int effectNum;
        void setupEffect();
        void selectEffect(string effectName);

        int backgroundMode = -1;
        int blendLevel = 0;
        ofImage firstFrame;

        cv::BackgroundSubtractorMOG2 bgSubtractor;
        ofImage effectBgExtract (cv::Mat color_img) ;
        void effectGoodOpticalFlow(cv::Mat color_img);
        void effectFeatureLines(cv::Mat color_img);

        cv::GoodFeaturesToTrackDetector goodFeatureDetector;
        std::vector<cv::Point2f> lastPointsOpticalFlow;
        std::vector<cv::KeyPoint> keyPointsOpticalFlow;

        cv::Mat lastImgOpticalFlow;
        bool firstFrameOpticalFlow = true;
        int MAX_FEATURES = 500;

        bool findInVector(vector<string> haystack, string needle);

};
